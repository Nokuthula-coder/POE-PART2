/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapplication;

/**
 *
 * @author RC_Student_Lab
 */
public class Quickchatapplication {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
